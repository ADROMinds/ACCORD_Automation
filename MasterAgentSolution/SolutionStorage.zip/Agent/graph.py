import logging
from typing import Dict, Any
from dotenv import load_dotenv

load_dotenv()

from langgraph.graph import StateGraph, START, END
from state import OverallState, GraphInput, GraphOutput
from nodes.data_fabric import fetch_data_fabric_node
from nodes.intent_classifier import intent_classifier_node
from nodes.ack_generator import ack_generator_node
from nodes.acord_classifier import acord_classifier_node
from nodes.extractor import extraction_node
from nodes.router import master_router
from nodes.postprocess import postprocess_node

# Configure logger
logger = logging.getLogger(__name__)

# Initialize StateGraph with explicit schemas for UiPath integration
workflow = StateGraph(
    OverallState,
    input_schema=GraphInput,
    output_schema=GraphOutput
)

# Add Nodes
workflow.add_node("fetch_data_fabric", fetch_data_fabric_node)
workflow.add_node("intent_classification", intent_classifier_node)
workflow.add_node("generate_ack", ack_generator_node)
workflow.add_node("classify_acord", acord_classifier_node)
workflow.add_node("extraction", extraction_node)
workflow.add_node("postprocess", postprocess_node)

# Define Edges
workflow.add_edge(START, "fetch_data_fabric")
workflow.add_edge("fetch_data_fabric", "intent_classification")

# Conditional Routing after Intent Classification
workflow.add_conditional_edges(
    "intent_classification",
    master_router,
    {
        "generate_ack": "generate_ack",
        "classify_acord": "classify_acord"
    }
)

# Paths to postprocessing
workflow.add_edge("generate_ack", "postprocess")
workflow.add_edge("classify_acord", "extraction")
workflow.add_edge("extraction", "postprocess")
workflow.add_edge("postprocess", END)

# Compile Application
graph = workflow.compile()

async def run_master_agent(email_data: Dict[str, Any], confidence_threshold: float = 0.80) -> Dict[str, Any]:
    """
    Executes the Master Agent workflow for email processing.
    """
    try:
        logger.info(f"Starting Master Agent for email from: {email_data.get('sender')}")
        
        initial_state: Dict[str, Any] = {
            "email": email_data,
            "email_payload": email_data,
            "data_fabric_context": {},
            "intent_analysis": {"intent": None, "confidence": 0.0, "status": "pending", "raw_output": None},
            "acord_analysis": {"acord_type": None, "confidence": 0.0, "status": "pending", "raw_output": None},
            "extraction_results": {"extracted_data": None, "confidence": 0.0, "status": "pending", "raw_output": None},
            "confidence_threshold": confidence_threshold,
            "ack_email_body": None,
            "current_step": "start",
            "flags": [],
            "human_review_required": False,
            "audit_log": [],
            "error_log": []
        }
        
        # Result will be the output of the postprocess_node
        result = await graph.ainvoke(initial_state)
        return result
        
    except Exception as e:
        logger.exception(f"Master Agent failed: {str(e)}")
        raise e
