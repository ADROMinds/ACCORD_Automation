import os
import logging
from fastapi import Security, HTTPException, status
from fastapi.security.api_key import APIKeyHeader
from dotenv import load_dotenv

# Initialize logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

# Configuration
API_KEY_NAME = "X-API-Key"
api_key_header = APIKeyHeader(name=API_KEY_NAME, auto_error=False)

def get_master_api_key() -> str:
    """Retrieves and validates the master API key from environment."""
    key = os.getenv("MASTER_AGENT_API_KEY")
    if not key:
        logger.critical("MASTER_AGENT_API_KEY is not set in environment variables.")
        # We don't raise here but handle it in the dependency to allow the app to start
        return ""
    return key

async def verify_api_key(api_key: str = Security(api_key_header)):
    """
    FastAPI dependency to verify the X-API-Key header.
    Returns the valid key or raises 401 Unauthorized.
    """
    master_key = get_master_api_key()
    
    if not master_key:
        logger.error("Authentication attempted but MASTER_AGENT_API_KEY is missing from server config.")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Server security configuration error."
        )

    logger.info(f"Auth attempt received for header: {API_KEY_NAME}")

    if not api_key:
        logger.warning("Auth attempt failed: Missing API Key.")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="API Key missing",
            headers={"WWW-Authenticate": API_KEY_NAME},
        )

    if api_key != master_key:
        logger.warning("Auth attempt failed: Invalid API Key.")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid API Key",
            headers={"WWW-Authenticate": API_KEY_NAME},
        )

    logger.info("Auth attempt successful.")
    return api_key
