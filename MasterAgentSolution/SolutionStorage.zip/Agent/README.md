# Email-to-ACORD Intelligence Master Agent

This is a **Master Agent** built with **LangGraph**, **Gemini**, and the **UiPath Python SDK**. It orchestrates a complex insurance document processing workflow designed to run as a **UiPath Coded Agent** in Studio Web.

## Workflow Overview

1.  **Email Trigger**: Takes an `EmailSchema` as input (Subject, Body, Sender, etc.).
2.  **Context Enrichment**: Fetches customer/policy data from **UiPath Data Fabric**.
3.  **Intent Classification**: Invokes a specialized **Intent Classifier Agent** on Orchestrator.
4.  **Confidence Routing**:
    *   **Low Confidence**: Generates a personalized acknowledgment email using **Gemini** and terminates.
    *   **High Confidence**: Proceeds to the next stage.
5.  **ACORD Classification**: Invokes an **ACORD Classifier Agent** on Orchestrator to identify form types.
6.  **Data Extraction**: Invokes a **Final Extraction Agent** to pull specific data from identified forms.
7.  **Output**: Returns the full audit trail and extraction results.

## Key Components

*   **`main.py`**: Entry point for both Studio Web (`agent_main`) and local API testing (FastAPI).
*   **`graph.py`**: The LangGraph state machine definition.
*   **`state.py`**: TypedDict state management.
*   **`nodes/`**: Specialized processing nodes (Data Fabric, Orchestrator Invocation, LLM Generation).

## Setup

1.  **Environment Variables**: Create a `.env` file based on `.env.example`.
    *   `GOOGLE_API_KEY`: For Gemini (Ack Generation).
2.  **Orchestrator Setup**: Ensure the following processes are published to your folder:
    *   `IntentClassifierAgent`
    *   `ACORDClassifierAgent`
    *   `FinalExtractionAgent`
3.  **Data Fabric**: Ensure a `CustomerRecords` entity exists with an `Email` field.

## Studio Web Integration

This project is structured as a **Coded Agent**. To run in Studio Web:
1.  Zip the `Agent` folder contents.
2.  Upload as a **Coded Agent** or use the **Studio Web Local Workspace** sync.
3.  The `agent_main` function in `main.py` is the primary entry point.
