from typing import TypedDict, Annotated, List, Dict, Any, Optional
from pydantic import BaseModel, Field
import operator

def append_reducer(left: list, right: list) -> list:
    """Reducer function to append items to a list in the state."""
    if not left:
        return right
    if not right:
        return left
    return left + right

class EmailSchema(TypedDict):
    """Schema for the incoming email trigger."""
    subject: str
    body: str
    sender: str
    received_at: str
    attachment_names: List[str]
    message_id: str

class AgentResult(TypedDict):
    """Generic structure for sub-agent results from Orchestrator."""
    intent: Optional[str]
    confidence: float
    acord_type: Optional[str]
    extracted_data: Optional[Dict[str, Any]]
    status: str
    raw_output: Any

class OverallState(TypedDict):
    """
    The global state for the Email-to-ACORD Intelligence Master Agent.
    """
    # --- Input Data ---
    email: EmailSchema  # The primary input email data
    email_payload: Optional[Dict[str, Any]] # Alias for UiPath Studio Web input compatibility
    data_fabric_context: Dict[str, Any]  # Context retrieved from UiPath Data Fabric
    
    # --- Classification Results ---
    intent_analysis: AgentResult  # Result from the Intent Classifier Agent
    acord_analysis: AgentResult   # Result from the ACORD Classifier Agent
    extraction_results: AgentResult # Result from the Final Extraction Agent
    
    # --- Logic Controls ---
    confidence_threshold: float  # Configurable threshold for auto-acknowledgment
    ack_email_body: Optional[str] # LLM-generated acknowledgment email
    
    # --- Workflow State ---
    current_step: str
    flags: List[str]
    human_review_required: bool
    
    # --- Logs & Auditing ---
    audit_log: Annotated[List[Dict[str, Any]], append_reducer]
    error_log: Annotated[List[Dict[str, Any]], append_reducer]

class GraphInput(BaseModel):
    """Schema for the graph input."""
    email: Optional[Dict[str, Any]] = Field(default=None, description="The incoming email data.")
    email_payload: Optional[Dict[str, Any]] = Field(default=None, description="The incoming email data to process.")
    confidence_threshold: float = Field(default=0.8, description="Threshold for auto-acknowledgment.")

class GraphOutput(BaseModel):
    """Schema for the graph output."""
    intent: Optional[str] = None
    acord_type: Optional[str] = None
    extraction: Optional[Dict[str, Any]] = None
    ack_email: Optional[str] = None
    audit: List[Dict[str, Any]] = Field(default_factory=list)
