import logging
from typing import Dict, Any
from state import OverallState

# Configure logger
logger = logging.getLogger(__name__)

def postprocess_node(state: OverallState) -> Dict[str, Any]:
    """
    Formats the final state for the Studio Web output.
    """
    logger.info("Formatting final output for Studio Web.")
    
    intent_analysis = state.get("intent_analysis", {})
    acord_analysis = state.get("acord_analysis", {})
    extraction_results = state.get("extraction_results", {})
    
    return {
        "intent": intent_analysis.get("intent") if isinstance(intent_analysis, dict) else None,
        "acord_type": acord_analysis.get("acord_type") if isinstance(acord_analysis, dict) else None,
        "extraction": extraction_results.get("extracted_data") if isinstance(extraction_results, dict) else None,
        "ack_email": state.get("ack_email_body"),
        "audit": state.get("audit_log", [])
    }
