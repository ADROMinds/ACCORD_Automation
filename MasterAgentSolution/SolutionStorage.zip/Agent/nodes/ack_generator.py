import os
import logging
from langchain_openai import ChatOpenAI
from state import OverallState

# Configure logger
logger = logging.getLogger(__name__)

def ack_generator_node(state: OverallState) -> OverallState:
    """
    Generates a personalized acknowledgment email using a Hugging Face 
    OpenAI-compatible endpoint.
    """
    mock_mode = os.getenv("MOCK_MODE", "false").lower() == "true"
    if "email" not in state or not state["email"]:
        state["email"] = state.get("email_payload", {})

    if mock_mode:
        logger.info("[MOCK] Simulating Acknowledgment Email Generator...")
        state["ack_email_body"] = f"Thank you {state['email']['sender']}. We have received your email regarding '{state['email']['subject']}' and are reviewing it."
        state["audit_log"].append({
            "node": "ack_generator",
            "action": "email_generated",
            "llm_provider": "mock",
            "success": True
        })
        return state

    logger.info("Generating acknowledgment email via Hugging Face Target Endpoint...")
    
    try:
        # Configuration from environment variables
        endpoint_url = os.getenv("HF_ENDPOINT_URL")
        api_token = os.getenv("HF_API_TOKEN")
        model_name = os.getenv("HF_MODEL_NAME", "tgi") # Default to 'tgi' if not specified

        if not endpoint_url or not api_token:
            raise ValueError("HF_ENDPOINT_URL and HF_API_TOKEN must be set in environment.")

        # Initialize the OpenAI-compatible client
        llm = ChatOpenAI(
            base_url=endpoint_url,
            api_key=api_token,
            model=model_name,
            temperature=0.7
        )

        prompt = f"""You are a professional customer service assistant for an insurance company.
The customer sent an email with the following details:
Sender: {state['email']['sender']}
Subject: {state['email']['subject']}
Body: {state['email']['body']}

The system was unable to confidently classify the intent (Confidence: {state['intent_analysis']['confidence']}).
Generate a polite acknowledgment email stating that we have received their request and a representative will review it shortly.
Do NOT make up any specific details. Keep it professional and empathetic.

Return ONLY the email body text."""

        response = llm.invoke(prompt)
        state["ack_email_body"] = response.content.strip()
        
        logger.info(f"Acknowledgment email generated successfully using model: {model_name}")

    except Exception as e:
        logger.error(f"Error generating acknowledgment email via HF: {str(e)}")
        state["ack_email_body"] = "We have received your email and are reviewing it. Thank you for your patience."
        state["error_log"].append({"node": "ack_generator", "error": str(e)})

    # Audit Log
    state["audit_log"].append({
        "node": "ack_generator",
        "action": "email_generated",
        "llm_provider": "hugging_face",
        "success": bool(state["ack_email_body"])
    })
    
    return state
