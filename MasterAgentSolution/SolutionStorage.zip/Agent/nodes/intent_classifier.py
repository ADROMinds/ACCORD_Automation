import os
import json
import time
import logging
import requests
from urllib.parse import urlencode
from state import OverallState

logger = logging.getLogger(__name__)

# ── Credentials & Config ─────────────────────────────────────────────────────
CLIENT_ID     = "8b0446db-e88a-4e3a-ad1c-3951e156bfea"
CLIENT_SECRET = "iKv8UXB$@giyl*T$06L*rmmtoCGIRMIY714iH_SOJRa?OW%O3L0SGe8?YYzhKkxw"
ORG           = "hackathon26_585"
TENANT        = "DefaultTenant"
FOLDER_ID     = "3091065"
RELEASE_KEY   = "a2c12580-d411-44c7-94c8-881941bccf81"
BASE_URL      = f"https://staging.uipath.com/{ORG}/{TENANT}/orchestrator_"

def get_token() -> str:
    payload = urlencode({
        "grant_type":    "client_credentials",
        "client_id":     CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "scope":         "OR.Jobs OR.Execution OR.Folders"
    })
    token = requests.post(
        "https://staging.uipath.com/identity_/connect/token",
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        data=payload
    ).json()["access_token"]
    return token

def intent_classifier_node(state: OverallState) -> OverallState:
    """
    Invokes the Intent Classifier Agent on Orchestrator.
    If MOCK_MODE is True, returns simulated data.
    """

    # ── Normalize email from state ────────────────────────────────────────────
    if "email" not in state or not state["email"]:
        state["email"] = state.get("email_payload", {})

    # ── Real Invocation ───────────────────────────────────────────────────────
    logger.info("Invoking Intent Classifier Agent on Orchestrator...")
    try:
        # Step 1: Get Token
        token = get_token()
        logger.info("Token OK ✅")

        headers = {
            "Authorization":               f"Bearer {token}",
            "Content-Type":                "application/json",
            "X-UIPATH-OrganizationUnitId": FOLDER_ID
        }

        # Step 2: Build Input Arguments
        input_args = {
            "email_payload":        state["email"],
            "confidence_threshold": state.get("confidence_threshold", 0.85)
        }

        # Step 3: Start Job
        start_resp = requests.post(
            f"{BASE_URL}/odata/Jobs/UiPath.Server.Configuration.OData.StartJobs",
            headers=headers,
            json={
                "startInfo": {
                    "ReleaseKey":     RELEASE_KEY,
                    "Strategy":       "ModernJobsCount",
                    "JobsCount":      1,
                    "InputArguments": json.dumps(input_args)
                }
            }
        )

        if start_resp.status_code not in [200, 201]:
            raise Exception(f"Failed to start job: {start_resp.text}")

        job_id = start_resp.json()["value"][0]["Id"]
        logger.info(f"Job started. ID: {job_id}")

        # Step 4: Poll Until Complete
        for i in range(60):  # max 5 minutes
            status_resp = requests.get(
                f"{BASE_URL}/odata/Jobs({job_id})",
                headers=headers
            ).json()

            job_state = status_resp["State"]
            logger.info(f"[{i*5}s] Job State: {job_state}")

            if job_state == "Successful":
                logger.info("✅ Job Completed Successfully!")
                output = status_resp.get("OutputArguments")
                outputs = json.loads(output) if output else {}

                state["intent_analysis"] = {
                    "intent":     outputs.get("intent"),
                    "confidence": outputs.get("confidence", 0.0),
                    "status":     "completed",
                    "raw_output": outputs
                }
                break

            elif job_state in ["Faulted", "Stopped", "Abandoned"]:
                raise Exception(f"Job failed with state: {job_state} | Info: {status_resp.get('Info')}")

            time.sleep(5)

        else:
            raise Exception("Timeout — job did not complete within 5 minutes")

    except Exception as e:
        logger.error(f"Intent Classifier invocation failed: {str(e)}")
        state["intent_analysis"] = {
            "intent":     None,
            "confidence": 0.0,
            "status":     "failed",
            "raw_output": str(e)
        }
        state["error_log"].append({"node": "intent_classifier", "error": str(e)})

    return state