import os
import logging
from uipath.platform import UiPath
from state import OverallState

# Configure logger
logger = logging.getLogger(__name__)

def extraction_node(state: OverallState) -> OverallState:
    """
    Invokes the Final Extraction Agent on Orchestrator.
    If MOCK_MODE is True, returns simulated data.
    """
    if "email" not in state or not state["email"]:
        state["email"] = state.get("email_payload", {})

    mock_mode = os.getenv("MOCK_MODE", "false").lower() == "true"

    if mock_mode:
        logger.info("[MOCK] Simulating Extraction Agent...")
        state["extraction_results"] = {
            "extracted_data": {
                "policy_holder": state["email"]["sender"],
                "industry": "Chemical Manufacturing",
                "risk_rating": "Medium-High"
            },
            "confidence": 0.88,
            "status": "completed",
            "raw_output": {"mock": True}
        }
        return state

    logger.info(f"Invoking Extraction Agent for ACORD {state['acord_analysis']['acord_type']}...")
    try:
        sdk = UiPath()
        input_args = {
            "acord_type": state["acord_analysis"]["acord_type"],
            "email_data": state["email"],
            "context": state["data_fabric_context"]
        }
        
        job_result = sdk.orchestrator.processes.invoke_process(
            name=os.getenv("EXTRACTION_AGENT_NAME", "FinalExtractionAgent"),
            input_arguments=input_args
        )
        
        outputs = job_result.get("output_arguments", {})
        state["extraction_results"] = {
            "extracted_data": outputs.get("data"),
            "confidence": outputs.get("confidence", 0.0),
            "status": "completed",
            "raw_output": outputs
        }
    except Exception as e:
        logger.error(f"Extraction failed: {str(e)}")
        state["extraction_results"] = {"extracted_data": None, "confidence": 0.0, "status": "failed", "raw_output": str(e)}
        state["error_log"].append({"node": "extraction", "error": str(e)})

    return state
