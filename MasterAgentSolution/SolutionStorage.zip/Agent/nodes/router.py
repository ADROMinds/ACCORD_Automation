import logging
from typing import Literal
from state import OverallState

# Configure logger
logger = logging.getLogger(__name__)

def master_router(state: OverallState) -> Literal["generate_ack", "classify_acord"]:
    """
    Determines whether to acknowledge the email (low confidence) or proceed to ACORD classification.
    """
    confidence = state["intent_analysis"].get("confidence", 0.0)
    threshold = state.get("confidence_threshold", 0.80)
    
    logger.info(f"Routing check: Confidence {confidence} vs Threshold {threshold}")
    
    if confidence < threshold:
        logger.info("Low confidence detected. Routing to Acknowledgment Generator.")
        return "generate_ack"
    else:
        logger.info("High confidence detected. Routing to ACORD Classifier.")
        return "classify_acord"
