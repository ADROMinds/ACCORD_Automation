import os
import logging
from uipath.platform import UiPath
from state import OverallState

# Configure logger
logger = logging.getLogger(__name__)

def acord_classifier_node(state: OverallState) -> OverallState:
    """
    Invokes the ACORD Classifier Agent on Orchestrator.
    If MOCK_MODE is True, returns simulated data.
    """
    if "email" not in state or not state["email"]:
        state["email"] = state.get("email_payload", {})

    mock_mode = os.getenv("MOCK_MODE", "false").lower() == "true"

    if mock_mode:
        logger.info("[MOCK] Simulating ACORD Classifier...")
        state["acord_analysis"] = {
            "acord_type": "ACORD 125",
            "confidence": 0.90,
            "status": "completed",
            "raw_output": {"mock": True}
        }
        return state

    logger.info("Invoking ACORD Classifier Agent...")
    try:
        sdk = UiPath()
        input_args = {
            "email_body": state["email"]["body"],
            "attachments": state["email"]["attachment_names"],
            "intent": state["intent_analysis"]["intent"]
        }
        
        job_result = sdk.orchestrator.processes.invoke_process(
            name=os.getenv("ACORD_AGENT_NAME", "ACORDClassifierAgent"),
            input_arguments=input_args
        )
        
        outputs = job_result.get("output_arguments", {})
        state["acord_analysis"] = {
            "acord_type": outputs.get("acord_type"),
            "confidence": outputs.get("confidence", 0.0),
            "status": "completed",
            "raw_output": outputs
        }
    except Exception as e:
        logger.error(f"ACORD Classifier failed: {str(e)}")
        state["acord_analysis"] = {"acord_type": None, "confidence": 0.0, "status": "failed", "raw_output": str(e)}
        state["error_log"].append({"node": "acord_classifier", "error": str(e)})

    return state
