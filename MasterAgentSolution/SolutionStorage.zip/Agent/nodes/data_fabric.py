import os
import logging
from typing import Dict, Any
from uipath.platform import UiPath
from state import OverallState

# Configure logger
logger = logging.getLogger(__name__)

def fetch_data_fabric_node(state: OverallState) -> OverallState:
    """
    Fetches context from Data Fabric. 
    If MOCK_MODE is True, returns simulated context.
    """
    if "email" not in state or not state["email"]:
        state["email"] = state.get("email_payload", {})

    mock_mode = os.getenv("MOCK_MODE", "false").lower() == "true"

    if mock_mode:
        logger.info("[MOCK] Simulating Data Fabric fetch...")
        state["data_fabric_context"] = {
            "CustomerID": "CUST-999",
            "Segment": "Commercial",
            "Status": "Active"
        }
        return state

    email_sender = state["email"]["sender"]
    logger.info(f"Fetching Data Fabric context for: {email_sender}")
    try:
        sdk = UiPath()
        records = sdk.data_fabric.query_records(
            entity_name=os.getenv("DATA_FABRIC_ENTITY", "CustomerRecords"),
            filter=f"Email eq '{email_sender}'",
            top=1
        )
        if records.data:
            state["data_fabric_context"] = records.data[0]
        else:
            state["data_fabric_context"] = {}
    except Exception as e:
        logger.error(f"Error fetching from Data Fabric: {str(e)}")
        state["data_fabric_context"] = {}
        state["error_log"].append({"node": "data_fabric", "error": str(e)})

    return state
