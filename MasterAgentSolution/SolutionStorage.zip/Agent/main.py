import logging
import asyncio
from typing import Dict, Any
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

from graph import graph, run_master_agent

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

async def agent_main(email_payload: Dict[str, Any], confidence_threshold: float = 0.80) -> Dict[str, Any]:
    """
    Standard entry point for UiPath Studio Web Coded Agent.
    Input: dictionary matching EmailSchema.
    """
    logger.info("Studio Web Master Agent invoked.")
    try:
        result = await run_master_agent(email_payload, confidence_threshold=confidence_threshold)
        return result
    except Exception as e:
        logger.error(f"Studio Web Execution Error: {str(e)}")
        return {"error": str(e), "status": "failed"}

# Wrapper for synchronous invocation
def run_agent(email_payload: Dict[str, Any], confidence_threshold: float = 0.80) -> Dict[str, Any]:
    return asyncio.run(agent_main(email_payload, confidence_threshold))

# The 'graph' object is imported from graph.py and exported here for LangGraph runtime
__all__ = ["graph", "agent_main", "run_agent"]
